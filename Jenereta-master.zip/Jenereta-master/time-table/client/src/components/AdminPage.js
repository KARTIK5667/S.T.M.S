import React, { Component } from "react";

class AdminPage extends Component {
  render() {
    return (
      <div>
        <div>
          <button type="button">Teacher's Name</button>
        </div>
        <div>
          <button type="button">Class and Sec</button>
        </div>
        <div>
          <button type="button">Subject</button>
        </div>
      </div>
    );
  }
}

export default AdminPage;
